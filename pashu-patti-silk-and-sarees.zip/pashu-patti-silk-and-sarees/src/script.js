// You can add any interactive JavaScript here if needed
console.log("Welcome to Passhu Patti Silk and Sarees!");
